import React, { useState } from "react";
import toast from "react-hot-toast";
import axios from "axios";
import { FiSearch } from "react-icons/fi";
const Student = () => {
  const baseApiURL = "http://localhost:8080";
  const [search, setSearch] = useState();
  const [data, setData] = useState({
    rollNo: "",
    firstName: "",
    lastName: "",
    email: "",
    mobileNo: "",
    birthdate:"",
    gender: "",
    courseName: "",
    addmissionYear:""
  });
  const [id, setId] = useState();

  const searchStudentHandler = (e) => {
    setId("");
    setData({
    rollNo: "",
    firstName: "",
    lastName: "",
    email: "",
    mobileNo: "",
    birthdate:"",
    gender: "",
    courseName: "",
    addmissionYear:""
    });
    e.preventDefault();
    //toast.loading("Getting Student");
    const headers = {
      "Content-Type": "application/json",
    };
    
    axios
      .get(
        `${baseApiURL}/students/rollno/${search}`,
        { headers }
      )
      .then((response) => {
        console.log("in faculty student ",response.data)
            toast.success(response.data.status);
            setData({...
              response.data
            })
            setId(data.id);
          }
      )      
      .catch((error) => {
        toast.dismiss();
        //toast.error(error.response.data);
        console.error(error);
      });
  };

  return (
    <div className="w-full mx-auto mt-10 flex justify-center items-start flex-col mb-10">
      <div className="flex justify-between items-center w-full">
        
      </div>
      <div className="my-6 mx-auto w-full">
        <form
          className="flex justify-center items-center border-2 border-blue-500 rounded w-[40%] mx-auto"
          onSubmit={searchStudentHandler}
        >
          <input
            type="text"
            className="px-6 py-3 w-full outline-none"
            placeholder="Enrollment No."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <button className="px-4 text-2xl hover:text-blue-500" type="submit">
            <FiSearch />
          </button>
        </form>
        {id && (
          <div className="mx-auto w-full bg-blue-50 mt-10 flex justify-between items-center p-10 rounded-md shadow-md">
            <div>
              <p className="text-2xl font-semibold">
                {data.firstName} {data.lastName}
              </p>
              <div className="mt-3">
                <p className="text-lg font-normal mb-2">
                  Enrollment No: {data.rollNo}
                </p>
                <p className="text-lg font-normal mb-2">
                  Phone Number: +91 {data.mobileNo}
                </p>
                <p className="text-lg font-normal mb-2">
                  Email Address: {data.email}
                </p>
                <p className="text-lg font-normal mb-2">
                  Course Name: {data.courseName}
                </p>
                <p className="text-lg font-normal mb-2"> 
                  BirthDate: {data.birthdate}
                </p>
                <p className="text-lg font-normal mb-2"> 
                  Admission Year: {data.addmissionYear}
                </p>
              </div>
            </div>
            {/* <img
              src={process.env.REACT_APP_MEDIA_LINK + "/" + data.profile}
              alt="student profile"
              className="h-[200px] w-[200px] object-cover rounded-lg shadow-md"
            /> */}
          </div>
        )}
      </div>
    </div>
  );
};

export default Student;
