import axios from "axios";
import React, { useEffect, useState } from "react";
// import Heading from "../../components/Heading";
import toast from "react-hot-toast";
import { BiArrowBack } from "react-icons/bi";


const Marks = () => {
  const baseApiURL = "http://localhost:8080";
  const [subject, setSubject] = useState();
  const [rollNo, setRollNo] = useState();
  const [studentData, setStudentData] = useState();
  const [selected, setSelected] = useState({
    rollNo: "",
    examType: "",
    marks:""
  });
  const loadStudentDetails = () => {
    if(selected.examType.trim().length!==0){
      const headers = {
        "Content-Type": "application/json",
      };
      axios
        .get(
          `${baseApiURL}/students`,
          { headers }
        )
        .then((response) => {
          
          //if (response.data.success) {
            setStudentData(response.data);
          // } else {
          //   toast.error(response.data.message);
          // }
        })
        .catch((error) => {
          console.error(error);
          toast.error(error.message);
        });
    }
    else{
      toast.error("Please select atleast Subject and Exam Type")
    }

  };

  const submitMarksHandler = () => {
    console.log(selected)
    let container = document.getElementById("markContainer");
    container.childNodes.forEach((enroll) => {
      setStudentMarksHandler(
        enroll.id,
        document.getElementById(enroll.id + "marks").value
      );
    });
  };

  const setStudentMarksHandler = (enrollment, value) => {
    const headers = {
      "Content-Type": "application/json",
    };
    axios
      .post(
        `${baseApiURL}/marks/addMarks`,
        {
          enrollmentNo: enrollment,
          [selected.examType]: {
            [selected.subject]: value,
          },
        },
        { headers }
      )
      .then((response) => {
        if (response.data.success) {
          toast.dismiss();
          toast.success(response.data.message);
        } else {
          toast.dismiss();
          toast.error(response.data.message);
        }
      })
      .catch((error) => {
        console.error(error);
        toast.error(error.message);
      });
  };

  

  const getSubjectData = () => {
    //toast.loading("Loading Subjects");
    axios
      .get(`${baseApiURL}/subjects`)
      .then((response) => {
        //console.log("in marks subject",response)
        //toast.dismiss();
       // if (response.data.success) {
          setSubject(response.data);
        // } else {
        //   toast.error(response.data.message);
        // }
      })
      .catch((error) => {
        toast.dismiss();
        toast.error(error.message);
      });
  };

  const handleChange=(event)=>{
    var mark=event.target.value;
    console.log("handle event",mark,selected.examType)
    if(selected.examType=="internal"){
      if(mark>=0 && mark<=40){
        setSelected({...selected,marks:mark})
      }
      else{
        toast.error("marks should be between 0 and 40")
      }
    }else{
      if(mark>=0 && mark<=60){
        setSelected({...selected,marks:mark})
      }
      else{
        toast.error("marks should be between 0 and 60")
      }
    }
  }

  useEffect(() => {
    loadStudentDetails();
    getSubjectData();
  }, []);

  const resetValueHandler = () => {
    setStudentData();
  };

  return (
    <div className="w-full mx-auto flex justify-center items-start flex-col my-10">
      <div className="relative flex justify-between items-center w-full">
        {/* <Heading title={`Upload Marks`} /> */}
        {studentData && (
          <button
            className="absolute right-2 flex justify-center items-center border-2 border-red-500 px-3 py-2 rounded text-red-500"
            onClick={resetValueHandler}
          >
            <span className="mr-2">
              <BiArrowBack className="text-red-500" />
            </span>
            Close
          </button>
        )}
      </div>
      {!studentData && (
        <>
          <div className="mt-10 w-full flex justify-evenly items-center gap-x-6">
            {/* <div className="w-full">
              <label htmlFor="rollNo" className="leading-7 text-base ">
              Enrollment No:
              </label>
              <select
                id="rollNo"
                className="px-2 bg-blue-50 py-3 rounded-sm text-base w-full accent-blue-700 mt-1"
                value={selected.rollNo}
                onChange={(e) =>
                  setSelected({ ...selected, rollNo: e.target.value })
                }
              >
                <option defaultValue>-- Select --</option>
                {rollNo &&
                  studentData.map((stud) => {
                    return (
                      <option value={stud.rollNo} key={stud.rollNo}>
                        {stud.rollNo}
                      </option>
                    );
                  })}
              </select>
            </div> */}
           
            <div className="w-full">
              <label htmlFor="subject" className="leading-7 text-base ">
                Select Subject
              </label>
              <select
                id="subject"
                className="px-2 bg-blue-50 py-3 rounded-sm text-base w-full accent-blue-700 mt-1"
                value={selected.subject}
                onChange={(e) =>
                  setSelected({ ...selected, subject: e.target.value })
                }
              >
                <option defaultValue>-- Select --</option>
                {subject &&
                  subject.map((subject) => {
                    return (
                      <option value={subject.name} key={subject.name}>
                        {subject.name}
                      </option>
                    );
                  })}
              </select>
            </div>
            <div className="w-full">
              <label htmlFor="examType" className="leading-7 text-base ">
                Select Exam Type
              </label>
              <select
                id="examType"
                className="px-2 bg-blue-50 py-3 rounded-sm text-base w-full accent-blue-700 mt-1"
                value={selected.examType}
                onChange={(e) =>
                  setSelected({ ...selected, examType: e.target.value })
                }
              >
                <option defaultValue>-- Select --</option>
                <option value="internal">Internal</option>
                <option value="external">External</option>
              </select>
            </div>
          </div>
          <button
            className="bg-blue-50 px-4 py-2 mt-8 mx-auto rounded border-2 border-blue-500 text-black"
            onClick={loadStudentDetails}
          >
            Load Student Data
          </button>
        </>
      )}
      {studentData && studentData.length !== 0 && (
        <>
          <p className="mt-4 text-lg">
            Upload {selected.examType} Marks Of {selected.branch} Semester{" "}
            {selected.semester} of {selected.subject}
          </p>
          <div
            className="w-full flex flex-wrap justify-center items-center mt-8 gap-4"
            id="markContainer"
          >
            {studentData.map((student) => {
              return (
                <div
                  key={student.rollNo}
                  className="w-[30%] flex justify-between items-center border-2 border-blue-500 rounded"
                  id={student.rollNo}
                  onChange={(e)=>{setSelected({...selected,rollNo:student.rollNo})}}
                >
                  <p className="text-lg px-4 w-1/2 bg-blue-50">
                    {student.rollNo}
                  </p>

                 
                    <input
                      type="number"
                      className="px-6 py-2 focus:ring-0 outline-none w-1/2"
                      placeholder="Enter Marks"
                      id={`${student.rollNo}marks`}
                      onChange={handleChange}
                      max={40}
                      
                    />
                  
                
                 <button
                 className="bg-blue-500 px-6 py-3 mt-8 mx-auto rounded text-white"
                 onClick={submitMarksHandler}
               >
                 Upload Student Marks
               </button>
               </div>
              );
              
            })}
          </div>
         
        </>
      )}
    </div>
  );
};

export default Marks;
