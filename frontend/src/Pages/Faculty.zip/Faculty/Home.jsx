import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Profile from "./Profile";
import Timetable from "./Timetable";
import { Toaster } from "react-hot-toast";
import Material from "./Material";
import Marks from "./Marks";
import Student from "./Student";
import Lognavbar from "../../Components/Lognavbar";
const Home = () => {
  const router = useLocation();
  const navigate = useNavigate();
  const [selectedMenu, setSelectedMenu] = useState("My Profile");
  const [load, setLoad] = useState(false);
  useEffect(() => {
    if (router.state === null) {
      navigate("/");
    }
    setLoad(true);
  }, [navigate, router.state]);

  const getButtonClass = (menu) => {
    return `text-center rounded-sm px-4 py-2 w-1/5 cursor-pointer transition-all ${selectedMenu === menu
      ? "border-bottom border-primary bg-light rounded-sm"
      : "bg-primary text-white hover:bg-secondary border-bottom border-primary"
      }`;
  };

  return (
    <section>
      {load && (
        <>
          <Lognavbar />
          <div className="container max-w-6xl mx-auto">
            <ul className="d-flex justify-content-evenly align-items-center gap-3 my-4">
              <li
                className={getButtonClass("My Profile")}
                onClick={() => setSelectedMenu("My Profile")}
              >
                My Profile
              </li>
              <li
                className={getButtonClass("Student Info")}
                onClick={() => setSelectedMenu("Student Info")}
              >
                Student Info
              </li>
              <li
                className={getButtonClass("Upload Marks")}
                onClick={() => setSelectedMenu("Upload Marks")}
              >
                Upload Marks
              </li>
              <li
                className={getButtonClass("Timetable")}
                onClick={() => setSelectedMenu("Timetable")}
              >
                Timetable
              </li>
              <li
                className={getButtonClass("Notice")}
                onClick={() => setSelectedMenu("Notice")}
              >
                Notice
              </li>
              <li
                className={getButtonClass("Material")}
                onClick={() => setSelectedMenu("Material")}
              >
                Material
              </li>
            </ul>
            {selectedMenu === "Timetable" && <Timetable />}
            {selectedMenu === "Upload Marks" && <Marks />}
            {selectedMenu === "Material" && <Material />}
            {/* {selectedMenu === "Notice" && <Notice />} */}
            {selectedMenu === "My Profile" && <Profile />}
            {selectedMenu === "Student Info" && <Student />}
          </div>
        </>
      )}
      <Toaster position="bottom-center" />
    </section>
  );
};

export default Home;
